package com.dairy.model;

import java.util.ArrayList;
import java.util.List;

public class Customer {
    private String id;
    private String name;
    private List<Double> milkLog; // Stores logs for last 10 days

    public Customer(String id, String name) {
        this.id = id;
        this.name = name;
        this.milkLog = new ArrayList<>();
        // Mocking last 10 days of data with placeholder values (in Liters)
        for (int i = 0; i < 10; i++) {
            this.milkLog.add(0.0);
        }
    }
    
    public Customer(String id, String name, double liter) {
        this.id = id;
        this.name = name;
        this.milkLog = new ArrayList<>();
        this.milkLog.add(liter);
        
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public List<Double> getMilkLog() { return milkLog; }
    public void setMilkLog(List<Double> milkLog) { this.milkLog = milkLog; }

    public double getTotalMilk() {
        return milkLog.stream().mapToDouble(Double::doubleValue).sum();
    }
}
