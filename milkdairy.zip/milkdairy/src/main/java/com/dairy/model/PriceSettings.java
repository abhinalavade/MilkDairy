package com.dairy.model;

public class PriceSettings {
    private double pricePerLiter = 50.0; // Default price

    public double getPricePerLiter() { return pricePerLiter; }
    public void setPricePerLiter(double pricePerLiter) { this.pricePerLiter = pricePerLiter; }
}
