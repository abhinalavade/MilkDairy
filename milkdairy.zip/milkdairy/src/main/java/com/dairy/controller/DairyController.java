package com.dairy.controller;

import com.dairy.repository.DairyRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DairyController {

    private final DairyRepository repository;

    public DairyController(DairyRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/")
    public String viewDashboard(Model model) {
        double currentPrice = repository.getSettings().getPricePerLiter();
        
        // Calculate cumulative total metric payouts across all customers
        double globalTotalPayout = repository.getAllCustomers().stream()
                .mapToDouble(c -> c.getTotalMilk() * currentPrice)
                .sum();

        model.addAttribute("customers", repository.getAllCustomers());
        model.addAttribute("pricePerLiter", currentPrice);
        model.addAttribute("globalTotalPayout", globalTotalPayout);
        return "dashboard";
    }

    @GetMapping("/settings")
    public String viewSettings(Model model) {
        model.addAttribute("settings", repository.getSettings());
        return "settings";
    }

    @PostMapping("/settings/update")
    public String updatePrice(@RequestParam("pricePerLiter") double price) {
        repository.getSettings().setPricePerLiter(price);
        return "redirect:/";
    }

    @PostMapping("/customer/add")
    public String addCustomer(@RequestParam("customerName") String name) {
        if(name != null && !name.trim().isEmpty()) {
            repository.addCustomer(name);
        }
        return "redirect:/";
    }
    
    @PostMapping("/customemilkr/add")
    public String addMilkToCustomer(@RequestParam("customer_ID") String customerID, @RequestParam("customerName") String customerName, @RequestParam("liter") double liter) {
        if(customerID != null && !customerID.trim().isEmpty()) {
            repository.addCustomerMilk(customerID,customerName,liter);
        }
        return "redirect:/";
    }
}
