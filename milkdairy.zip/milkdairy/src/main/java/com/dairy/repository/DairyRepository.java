package com.dairy.repository;

import com.dairy.model.Customer;
import com.dairy.model.PriceSettings;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository
public class DairyRepository {
    private final List<Customer> customers = new ArrayList<>();
    private final PriceSettings settings = new PriceSettings();

    public DairyRepository() {
        
    }

    public List<Customer> getAllCustomers() { return customers; }
    public PriceSettings getSettings() { return settings; }
    
    public void addCustomer(String name) {
        String nextId = "C10" + (customers.size() + 1);
        customers.add(new Customer(nextId, name));
    }
    
	public void addCustomerMilk(String customerID, String customerName, double liter) {
		// TODO Auto-generated method stub
		customers.add(new Customer(customerID, customerName, liter));
	}
}
